# Communication Layers

popup.js          →          app.js          →          background.js
   ↓                           ↓                             ↓
this is where             this is where user           this is where the payload
user interaction          interaction verified         sent to the client
happens                   and the payload
                          created
