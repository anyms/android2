package app.spidy.pirum.interfaces

interface RenameListener {
    fun onSuccess()
    fun onFail()
}