package app.spidy.pirum.interfaces

interface DetectListener {
    fun onDetect(detect: HashMap<String, String>)
}