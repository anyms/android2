package app.spidy.pirum.utils

object C {
    const val CHANNEL_ID = "SERVICE_NOTIFICATION_CHANNEL_ID"

    const val SERVER_NOTIFICATION_ID = 101
    const val MUSIC_PLAYER_NOTIFICATION_ID = 102
    const val DOWNLOAD_NOTIFICATION_ID = 103
}